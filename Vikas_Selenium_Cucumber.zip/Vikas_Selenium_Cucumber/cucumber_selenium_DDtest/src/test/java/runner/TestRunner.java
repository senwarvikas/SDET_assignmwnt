package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features = "src/test/java/Features/Assignment1.feature", 
		glue = { "StepDefinition" },
		tags = {"@RegressionTest"},
		plugin = { "pretty" , "html:target/Cucumber-report"}
		 
		)


public class TestRunner {

}